#include <iostream>

//Library to include for creating files
#include <fstream>

using namespace std;

int main() {

  //Creating the varible for the creation of the file 
  ofstream output;

  //Creating a varible for opening a file
  ifstream input;

  //This will create and open the file if it doesn't already exist in folder, or will just open file if it already does exist

  //If you want to open a file not in the folder you need to include the whole path
  output.open("numbers.txt");

  //How to write inside the created file
  output << 95 << " " << 73 << " " << 46;
  
  output.close();

  cout << "It is done" << endl;

  input.open("numbers.txt");

  int num1, num2, num3;

  input >> num1;
  input >> num2;
  input >> num3;

  cout << num1 + num2 + num3 << endl;

  input.close();

  input.open("numbers2.txt");

  int num4, num5, num6;

  input >> num4 >> num5 >> num6;

  cout << num4 + num5 + num6 << endl;

  input.close();

  return 0;

}

